
"""define the settings for corps(python agent)

"""

